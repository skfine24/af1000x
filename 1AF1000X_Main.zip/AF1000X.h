#ifndef AF1000X_H
#define AF1000X_H

#include "AF1000X_BINDING.h"
#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <RF24.h>
#include <Preferences.h>
#include <VL53L1X.h>
#include "ICM45686.h"


// Hover 학습 헤더(너가 만든 파일)
#include "AF1000X_Hover.h"


/* ============================================================================
 * AF1000X Core (ESP32-S3)
 * - Sensor POST + LED
 * - Altitude fusion (ToF + SPL06)
 * - Optical flow integration (PMW3901) + yaw rotation
 * - Flight lock if sensors fail
 * - Hover PWM auto-learning (via AF1000X_Hover.h)
 * - {0xE8, 0xE8, 0xF0, 0xF0, 0xE1} 페어링 주소
 * ========================================================================== */

// ----------------------- Mode constants (u8) -----------------------
static constexpr uint8_t MODE_READY     = 0;
static constexpr uint8_t MODE_TAKEOFF   = 1;
static constexpr uint8_t MODE_HOVERING  = 2;
static constexpr uint8_t MODE_LANDING   = 3;
static constexpr uint8_t MODE_EMERGENCY = 4;

// ----------------------- RF structs ------------------------
struct Signal {
  uint8_t throttle, roll, pitch, yaw, aux1, aux2;
  uint8_t speed; // 1~3
};

struct Telemetry {
  float vbat, alt, posX, posY;
  int rssi;
};

// ============================================================================
// Pins (필요하면 너 PCB에 맞춰 수정)
// ============================================================================
static const int PIN_RF_CE   = 2;
static const int PIN_RF_CSN  = 5;
static const uint8_t RF_ADDR[5] = {0xB1,0xB2,0xB3,0xB4,0x01};

// Motors (너가 확정한 값)
static const int PIN_M1 = 10;
static const int PIN_M2 = 11;
static const int PIN_M3 = 12;
static const int PIN_M4 = 13;

// I2C
static const int PIN_I2C_SDA = 3;
static const int PIN_I2C_SCL = 4;

// SPI
static const int PIN_SPI_SCK  = 33;
static const int PIN_SPI_MISO = 34;
static const int PIN_SPI_MOSI = 14;

// ToF
static const int PIN_VL53_XSHUT = 35;

// Optical Flow
static const int PIN_FLOW_CS     = 38;
static const int PIN_FLOW_MOTION = 37;

// Battery ADC
static const int PIN_BAT_ADC = 1;

// LEDs (센서 상태)
static const int PIN_LED_IMU  = 6;
static const int PIN_LED_BARO = 7;
static const int PIN_LED_TOF  = 8;
static const int PIN_LED_FLOW = 9;

// ============================================================================
// Tuning constants
// ============================================================================
static const float LOOP_DT = 0.02f;            // 50Hz
static const uint32_t FAILSAFE_MS = 300;

static const float ALT_SWITCH_M = 1.0f;
static const float TOF_EMA_A  = 0.25f;
static const float BARO_EMA_A = 0.05f;
static const float ALT_EMA_A  = 0.15f;

static const float TOF_JUMP_REJECT_M = 0.25f;

static const uint8_t FLOW_SQUAL_MIN = 20;
static const float   FLOW_MAX_STEP_M = 0.08f;

static const float POS_KP = 0.6f;
static const float YAW_KP = 1.5f;
static const float ALT_KP = 0.18f;
static const float ALT_KD = 0.06f;

static const float TAKEOFF_TARGET_M = 1.0f;
static const float LAND_DESCEND_MPS = 0.25f;
static const float READY_ALT_M      = 0.08f;

// PWM
static const uint32_t PWM_FREQ = 24000;
static const uint8_t  PWM_RES  = 8;

// ============================================================================
// Globals (Hover/EasyCommander에서 참조 가능한 이름들)
// ============================================================================
#ifdef AF1000X_IMPLEMENTATION

// RF
RF24 radio(PIN_RF_CE, PIN_RF_CSN);
Preferences prefs;
Signal receiverData{};
Telemetry telemetryData{};
uint32_t lastRxMs = 0;
bool failsafe = false;

float currentRoll  = 0.0f;
float currentPitch = 0.0f;


// mode (Hover 헤더가 uint8_t extern 기대)
volatile uint8_t currentMode = MODE_READY;

// targets / states (meters)
float targetAltitude = TAKEOFF_TARGET_M;
float currentAltitude = 0.0f;

float targetPosX = 0.0f, targetPosY = 0.0f;
float currentPosX = 0.0f, currentPosY = 0.0f;

float targetYaw = 0.0f;   // deg
float currentYaw = 0.0f;  // deg

int speedLevel = 1;
float moveSpeedSteps[3]  = {0.30f, 0.60f, 1.00f};
float climbSpeedSteps[3] = {0.20f, 0.40f, 0.70f};
float yawSpeedSteps[3]   = {30.0f, 60.0f, 120.0f};

float trimRoll = 0.0f, trimPitch = 0.0f;

// 고도 제어 기반 PWM (Hover 학습이 이 값을 자동으로 찾음)
int hoverThrottle = 140;

// 센서 OK/락
bool ok_imu=false, ok_baro=false, ok_tof=false, ok_flow=false;
bool flightLock = false;
bool calibrated = false;

// altitude filters
bool tofFiltInit=false;
float tof_m_filt=0.0f;
float tof_m_last_raw=0.0f;

bool baroInit=false;
float baro_alt_m_filt=0.0f;

bool altInit=false;
float alt_m_filt=0.0f;
float alt_m_prev=0.0f;

// flowK (m/count/m)
float flowK = 0.0022f;

// ToF
VL53L1X tof;

// IMU (ICM45686)
static ICM456xx IMU0(Wire, 0);
static ICM456xx IMU1(Wire, 1);
static ICM456xx* IMU = nullptr;
float gyroZ_bias = 0.0f;
float yaw_internal = 0.0f;
uint32_t lastYawUs = 0;

// motors ledc channels
int ch1=-1,ch2=-1,ch3=-1,ch4=-1;

// Baro baseline
float basePressurePa = 101325.0f;

// Flow cal state
enum FlowCalState : uint8_t { FC_IDLE, FC_TAKE_HOVER, FC_FORWARD, FC_PAUSE1, FC_BACK, FC_PAUSE2, FC_DONE, FC_ABORT };
FlowCalState flowCal = FC_IDLE;
uint32_t flowCal_t0 = 0;
float flowCal_dist_m = 0.50f;
float flowCal_hoverAlt_m = 0.80f;
float flowCal_pwr = 35.0f;

int32_t flowCal_sum_dx = 0;
uint32_t flowCal_samples = 0;
float flowCal_height_acc = 0.0f;
uint32_t flowCal_height_n = 0;
float flowCal_suggestK = 0.0f;
bool flowCal_reported = false;

#else
extern RF24 radio;
extern Preferences prefs;
extern Signal receiverData;
extern Telemetry telemetryData;
extern uint32_t lastRxMs;
extern bool failsafe;

extern volatile uint8_t currentMode;

extern float targetAltitude, currentAltitude;
extern float targetPosX, targetPosY, currentPosX, currentPosY;
extern float targetYaw, currentYaw;

extern int speedLevel;
extern float moveSpeedSteps[3], climbSpeedSteps[3], yawSpeedSteps[3];

extern float trimRoll, trimPitch;
extern int hoverThrottle;

extern bool ok_imu, ok_baro, ok_tof, ok_flow;
extern bool flightLock;
extern bool calibrated;

extern bool tofFiltInit;
extern float tof_m_filt, tof_m_last_raw;
extern bool baroInit;
extern float baro_alt_m_filt;
extern bool altInit;
extern float alt_m_filt, alt_m_prev;

extern float flowK;
extern VL53L1X tof;

extern float gyroZ_bias, yaw_internal;
extern uint32_t lastYawUs;

extern int ch1,ch2,ch3,ch4;

extern float basePressurePa;

extern enum FlowCalState : uint8_t { FC_IDLE, FC_TAKE_HOVER, FC_FORWARD, FC_PAUSE1, FC_BACK, FC_PAUSE2, FC_DONE, FC_ABORT } flowCal;
extern uint32_t flowCal_t0;
extern float flowCal_dist_m, flowCal_hoverAlt_m, flowCal_pwr;
extern int32_t flowCal_sum_dx;
extern uint32_t flowCal_samples;
extern float flowCal_height_acc;
extern uint32_t flowCal_height_n;
extern float flowCal_suggestK;
extern bool flowCal_reported;
#endif

// ============================================================================
// Helpers
// ============================================================================
static inline float clampf(float v,float lo,float hi){ return (v<lo)?lo:((v>hi)?hi:v); }
static inline void ledsInit(){
  pinMode(PIN_LED_IMU, OUTPUT);
  pinMode(PIN_LED_BARO, OUTPUT);
  pinMode(PIN_LED_TOF, OUTPUT);
  pinMode(PIN_LED_FLOW, OUTPUT);
  digitalWrite(PIN_LED_IMU, LOW);
  digitalWrite(PIN_LED_BARO, LOW);
  digitalWrite(PIN_LED_TOF, LOW);
  digitalWrite(PIN_LED_FLOW, LOW);
}
static inline void ledSet(bool imu_ok2,bool baro_ok2,bool tof_ok2,bool flow_ok2){
  digitalWrite(PIN_LED_IMU,  imu_ok2  ? HIGH : LOW);
  digitalWrite(PIN_LED_BARO, baro_ok2 ? HIGH : LOW);
  digitalWrite(PIN_LED_TOF,  tof_ok2  ? HIGH : LOW);
  digitalWrite(PIN_LED_FLOW, flow_ok2 ? HIGH : LOW);
}
static inline void ledAll(bool on){
  digitalWrite(PIN_LED_IMU,  on?HIGH:LOW);
  digitalWrite(PIN_LED_BARO, on?HIGH:LOW);
  digitalWrite(PIN_LED_TOF,  on?HIGH:LOW);
  digitalWrite(PIN_LED_FLOW, on?HIGH:LOW);
}
static inline void ledFailPattern(){
  for(int i=0;i<6;i++){
    ledAll(true);  delay(80);
    ledAll(false); delay(80);
  }
}
static inline float readBatteryVoltage(){
  int raw = analogRead(PIN_BAT_ADC);
  float vadc = (raw / 4095.0f) * 3.3f;
  return vadc * 3.0f; // 분압비 맞춰서 수정
}
inline void binding_ledAll(bool on) { ledAll(on); }

inline void binding_ledPairingTick() {
  static uint32_t t=0;
  static bool on=false;
  if (millis()-t > 120) { t=millis(); on=!on; }
  ledAll(on); // 페어링 중 전체 점멸
}

inline void binding_ledBoundOnce() {
  for(int i=0;i<2;i++){ ledAll(true); delay(80); ledAll(false); delay(80); }
}

inline void binding_ledErrorOnce() {
  for(int i=0;i<3;i++){ ledAll(true); delay(200); ledAll(false); delay(200); }
}

// ============================================================================
// Motors (LEDC)
// ============================================================================
static inline void motorsInit(){
  pinMode(PIN_M1, OUTPUT);
  pinMode(PIN_M2, OUTPUT);
  pinMode(PIN_M3, OUTPUT);
  pinMode(PIN_M4, OUTPUT);

  ch1 = ledcAttach(PIN_M1, PWM_FREQ, PWM_RES);
  ch2 = ledcAttach(PIN_M2, PWM_FREQ, PWM_RES);
  ch3 = ledcAttach(PIN_M3, PWM_FREQ, PWM_RES);
  ch4 = ledcAttach(PIN_M4, PWM_FREQ, PWM_RES);

  ledcWrite(ch1, 0);
  ledcWrite(ch2, 0);
  ledcWrite(ch3, 0);
  ledcWrite(ch4, 0);
}
static inline void motorsOff(){
  ledcWrite(ch1, 0);
  ledcWrite(ch2, 0);
  ledcWrite(ch3, 0);
  ledcWrite(ch4, 0);
}
static inline void motorControl(int thr, float r, float p, float ycmd){
  if(currentMode==MODE_READY || currentMode==MODE_EMERGENCY){ motorsOff(); return; }

  float fr = r + trimRoll;
  float fp = p + trimPitch;

  int m1 = constrain((int)(thr - fr + fp + ycmd), 0, 255);
  int m2 = constrain((int)(thr - fr - fp - ycmd), 0, 255);
  int m3 = constrain((int)(thr + fr - fp + ycmd), 0, 255);
  int m4 = constrain((int)(thr + fr + fp - ycmd), 0, 255);

  ledcWrite(ch1, m1);
  ledcWrite(ch2, m2);
  ledcWrite(ch3, m3);
  ledcWrite(ch4, m4);
}

// ============================================================================
// RF
// ============================================================================
static inline void radioInit(){
  radio.begin();
  radio.setDataRate(RF24_250KBPS);
  radio.setAutoAck(true);
  radio.enableAckPayload();
  radio.openReadingPipe(1, RF_ADDR);
  radio.startListening();
  lastRxMs = millis();
}
static inline void updateRadio(){
  if(radio.available()){
    radio.read(&receiverData, sizeof(Signal));
    lastRxMs = millis();
    failsafe = false;

    if(receiverData.speed >= 1 && receiverData.speed <= 3){
      speedLevel = receiverData.speed - 1;
    }

    telemetryData.vbat = readBatteryVoltage();
    telemetryData.alt  = currentAltitude;
    telemetryData.posX = currentPosX;
    telemetryData.posY = currentPosY;
    telemetryData.rssi = 1;

    radio.writeAckPayload(1, &telemetryData, sizeof(Telemetry));
  }

  if(millis() - lastRxMs > FAILSAFE_MS){
  failsafe = true;
  if(currentMode != MODE_READY && currentMode != MODE_EMERGENCY){

    // ✅ 추가: 착륙 시 목표를 현재로 리셋 (옆으로 도망 방지)
    targetPosX = currentPosX;
    targetPosY = currentPosY;
    targetYaw  = currentYaw;

    currentMode = MODE_LANDING;
   }
  }
}

// ============================================================================
// IMU (ICM45686) yaw integration
// ============================================================================
static inline float safeDt(float dt){ return (dt<=0.0f || dt>0.1f) ? 0.0f : dt; }

static inline bool imu_init_auto(){
  int ret = IMU0.begin();
  if(ret == 0) IMU = &IMU0;
  else {
    ret = IMU1.begin();
    if(ret == 0) IMU = &IMU1;
  }
  if(IMU == nullptr) return false;

  IMU->startAccel(200, 16);
  IMU->startGyro (200, 2000);

  gyroZ_bias = 0.0f;
  yaw_internal = 0.0f;
  lastYawUs = micros();
  return true;
}
static inline bool imu_calibrate_gyroZ(uint16_t samples=800, uint16_t delay_ms=2){
  if(!ok_imu || IMU == nullptr) return false;

  float sum=0.0f; uint16_t got=0;
  inv_imu_sensor_data_t d{};
  for(uint16_t i=0;i<samples;i++){
    if(IMU->getDataFromRegisters(d) == 0){
      sum += (float)d.gyro_data[2];
      got++;
    }
    delay(delay_ms);
  }
  if(got < (uint16_t)(samples*0.6f)) return false;

  gyroZ_bias = sum / (float)got;
  yaw_internal = 0.0f;
  lastYawUs = micros();
  return true;
}
static inline void imu_updateYaw(){
  if(!ok_imu || IMU == nullptr) return;
  inv_imu_sensor_data_t d{};
  if(IMU->getDataFromRegisters(d) != 0) return;

  float ax = (float)d.accel_data[0];
  float ay = (float)d.accel_data[1];
  float az = (float)d.accel_data[2];

  if (fabsf(az) < 0.2f) return;

  // 단위/스케일 정확하지 않아도 "뒤집힘 감지"엔 충분
  currentRoll  = atan2f(ay, az) * 57.2957795f;
  currentPitch = atan2f(-ax, sqrtf(ay*ay + az*az)) * 57.2957795f;

  uint32_t now = micros();
  float dt = (now - lastYawUs) * 1e-6f;
  lastYawUs = now;
  dt = safeDt(dt);
  if(dt <= 0.0f) return;

  float gz = (float)d.gyro_data[2] - gyroZ_bias;
  yaw_internal += gz * dt;

  while(yaw_internal > 180.0f) yaw_internal -= 360.0f;
  while(yaw_internal < -180.0f) yaw_internal += 360.0f;

  currentYaw = yaw_internal;
}
static inline void yawReset(){
  yaw_internal = 0.0f;
  lastYawUs = micros();
  currentYaw = 0.0f;
  targetYaw = 0.0f;
}

// ============================================================================
// SPL06 minimal driver (I2C) -> pressure -> altitude
// ============================================================================
static uint8_t  spl_addr = 0;
static bool     spl_ok = false;
static int16_t  spl_c0, spl_c1;
static int32_t  spl_c00, spl_c10;
static int16_t  spl_c01, spl_c11, spl_c20, spl_c21;
static int16_t  spl_c30 = 0;
static uint32_t kT = 524288;
static uint32_t kP = 253952;

static inline bool i2cProbe(uint8_t addr){
  Wire.beginTransmission(addr);
  return (Wire.endTransmission() == 0);
}
static inline bool i2cRead(uint8_t addr, uint8_t reg, uint8_t* buf, size_t n){
  Wire.beginTransmission(addr);
  Wire.write(reg);
  if(Wire.endTransmission(false) != 0) return false;
  if(Wire.requestFrom((int)addr, (int)n) != (int)n) return false;
  for(size_t i=0;i<n;i++) buf[i]=Wire.read();
  return true;
}
static inline bool i2cWrite1(uint8_t addr, uint8_t reg, uint8_t val){
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(val);
  return (Wire.endTransmission() == 0);
}
static inline int32_t signExtend24(uint32_t x){
  if(x & 0x800000) x |= 0xFF000000;
  return (int32_t)x;
}
static inline bool spl_readCoeffs(uint8_t addr){
  uint8_t b[18];
  if(!i2cRead(addr, 0x10, b, sizeof(b))) return false;

  int16_t c0_raw = ((int16_t)b[0] << 4) | (b[1] >> 4);
  int16_t c1_raw = (((int16_t)(b[1] & 0x0F)) << 8) | b[2];
  if(c0_raw & 0x0800) c0_raw |= 0xF000;
  if(c1_raw & 0x0800) c1_raw |= 0xF000;
  spl_c0 = c0_raw; spl_c1 = c1_raw;

  int32_t c00_raw = ((int32_t)b[3] << 12) | ((int32_t)b[4] << 4) | (b[5] >> 4);
  int32_t c10_raw = (((int32_t)(b[5] & 0x0F)) << 16) | ((int32_t)b[6] << 8) | b[7];
  if(c00_raw & 0x80000) c00_raw |= 0xFFF00000;
  if(c10_raw & 0x80000) c10_raw |= 0xFFF00000;
  spl_c00 = c00_raw; spl_c10 = c10_raw;

  spl_c01 = (int16_t)((b[8] << 8) | b[9]);
  spl_c11 = (int16_t)((b[10] << 8) | b[11]);
  spl_c20 = (int16_t)((b[12] << 8) | b[13]);
  spl_c21 = (int16_t)((b[14] << 8) | b[15]);

  return true;
}
static inline bool spl_init(){
  uint8_t cands[2] = {0x77, 0x76};
  for(uint8_t i=0;i<2;i++){
    uint8_t a = cands[i];
    if(!i2cProbe(a)) continue;

    uint32_t t0 = millis();
    while(millis() - t0 < 200){
      uint8_t m;
      if(!i2cRead(a, 0x08, &m, 1)) break;
      bool coef = m & (1<<7);
      bool sens = m & (1<<6);
      if(coef && sens) break;
      delay(10);
    }
    if(!spl_readCoeffs(a)) continue;
    spl_addr = a;

    i2cWrite1(spl_addr, 0x06, 0x14);
    i2cWrite1(spl_addr, 0x07, 0x80);
    i2cWrite1(spl_addr, 0x09, 0x80);
    i2cWrite1(spl_addr, 0x08, 0x07);

    kP = 253952;
    kT = 524288;

    spl_ok = true;
    return true;
  }
  spl_ok = false;
  return false;
}
static inline bool spl_readRaw(int32_t &praw, int32_t &traw){
  if(!spl_ok) return false;
  uint8_t b[6];
  if(!i2cRead(spl_addr, 0x00, b, 6)) return false;
  uint32_t p = ((uint32_t)b[0] << 16) | ((uint32_t)b[1] << 8) | b[2];
  uint32_t t = ((uint32_t)b[3] << 16) | ((uint32_t)b[4] << 8) | b[5];
  praw = signExtend24(p);
  traw = signExtend24(t);
  return true;
}
static inline bool spl_readPressurePa(float &pressurePa){
  int32_t praw, traw;
  if(!spl_readRaw(praw, traw)) return false;

  float Tsc = (float)traw / (float)kT;
  float Psc = (float)praw / (float)kP;

  float pcomp =
      (float)spl_c00 +
      Psc * ((float)spl_c10 + Psc * ((float)spl_c20 + Psc * (float)spl_c30)) +
      Tsc * (float)spl_c01 +
      Tsc * Psc * ((float)spl_c11 + Psc * (float)spl_c21);

  pressurePa = pcomp;
  return true;
}
static inline float pressureToAlt_m(float pPa, float p0Pa){
  return 44330.0f * (1.0f - powf(pPa / p0Pa, 1.0f / 5.255f));
}

// ============================================================================
// ToF VL53L1X
// ============================================================================
static inline bool tof_init(){
  pinMode(PIN_VL53_XSHUT, OUTPUT);
  digitalWrite(PIN_VL53_XSHUT, LOW);
  delay(5);
  digitalWrite(PIN_VL53_XSHUT, HIGH);
  delay(20);

  tof.setTimeout(50);
  if(!tof.init()) return false;

  tof.setDistanceMode(VL53L1X::Short);
  tof.setMeasurementTimingBudget(25000);
  tof.startContinuous(20);
  return true;
}
static inline bool tof_read_m(float &m){
  uint16_t mm = tof.readRangeContinuousMillimeters();
  if(tof.timeoutOccurred()) return false;
  if (tof.ranging_data.range_status != 0) return false;
  if(mm < 20 || mm > 3000) return false;
  m = mm * 0.001f;
  return true;
}

// ============================================================================
// PMW3901 minimal
// ============================================================================
static inline uint8_t pmw_read(uint8_t reg){
  digitalWrite(PIN_FLOW_CS, LOW);
  SPI.transfer(reg & 0x7F);
  delayMicroseconds(75);
  uint8_t v = SPI.transfer(0x00);
  digitalWrite(PIN_FLOW_CS, HIGH);
  delayMicroseconds(1);
  return v;
}
static inline void pmw_write(uint8_t reg, uint8_t val){
  digitalWrite(PIN_FLOW_CS, LOW);
  SPI.transfer(reg | 0x80);
  SPI.transfer(val);
  digitalWrite(PIN_FLOW_CS, HIGH);
  delayMicroseconds(1);
}
static inline bool pmw_init(){
  pinMode(PIN_FLOW_CS, OUTPUT);
  digitalWrite(PIN_FLOW_CS, HIGH);
  pinMode(PIN_FLOW_MOTION, INPUT);
  delay(5);

  uint8_t pid = pmw_read(0x00);
  if(pid != 0x49) return false;

  const uint8_t seq[][2] = {
    {0x7F,0x00},{0x61,0xAD},{0x7F,0x03},{0x40,0x00},{0x7F,0x05},
    {0x41,0xB3},{0x43,0xF1},{0x45,0x14},{0x5B,0x32},{0x5F,0x34},{0x7B,0x08},
    {0x7F,0x06},{0x44,0x1B},{0x40,0xBF},{0x4E,0x3F},
    {0x7F,0x00}
  };
  for(size_t i=0;i<sizeof(seq)/sizeof(seq[0]);i++){
    pmw_write(seq[i][0], seq[i][1]);
  }
  return true;
}
static inline bool pmw_readMotion(int16_t &dx, int16_t &dy, uint8_t &squal){
  digitalWrite(PIN_FLOW_CS, LOW);
  SPI.transfer(0x16 & 0x7F);
  delayMicroseconds(75);

  uint8_t motion = SPI.transfer(0);
  uint8_t dx_l   = SPI.transfer(0);
  uint8_t dx_h   = SPI.transfer(0);
  uint8_t dy_l   = SPI.transfer(0);
  uint8_t dy_h   = SPI.transfer(0);
  squal          = SPI.transfer(0);
  (void)motion;

  digitalWrite(PIN_FLOW_CS, HIGH);

  dx = (int16_t)((dx_h<<8) | dx_l);
  dy = (int16_t)((dy_h<<8) | dy_l);
  return true;
}

// ============================================================================
// Altitude fusion (ToF + Baro)
// ============================================================================
static inline void updateAltitudeFusion(){
  float tof_raw_m=0.0f;
  bool tof_ok_now = tof_read_m(tof_raw_m);

  if(tof_ok_now){
    if(tofFiltInit && fabsf(tof_raw_m - tof_m_last_raw) > TOF_JUMP_REJECT_M){
      tof_ok_now = false;
    } else {
      tof_m_last_raw = tof_raw_m;
      if(!tofFiltInit){ tof_m_filt = tof_raw_m; tofFiltInit=true; }
      tof_m_filt = tof_m_filt*(1.0f-TOF_EMA_A) + tof_raw_m*TOF_EMA_A;
    }
  }

  float pPa;
  bool baro_ok_now = spl_readPressurePa(pPa);
  float baro_alt_m = baro_ok_now ? pressureToAlt_m(pPa, basePressurePa) : baro_alt_m_filt;

  if(baro_ok_now){
    if(!baroInit){ baro_alt_m_filt = baro_alt_m; baroInit=true; }
    baro_alt_m_filt = baro_alt_m_filt*(1.0f-BARO_EMA_A) + baro_alt_m*BARO_EMA_A;
  }

  float tofW = 0.0f;
  if(tofFiltInit && tof_ok_now){
    tofW = (tof_m_filt <= ALT_SWITCH_M) ? 0.90f : 0.25f;
  }

  float fused = (tofW <= 0.0f) ? baro_alt_m_filt : (tofW*tof_m_filt + (1.0f-tofW)*baro_alt_m_filt);

  if(!altInit){
    alt_m_filt = fused;
    alt_m_prev = fused;
    currentAltitude = fused;
    altInit = true;
    return;
  }

  alt_m_prev = alt_m_filt;
  alt_m_filt = alt_m_filt*(1.0f-ALT_EMA_A) + fused*ALT_EMA_A;
  currentAltitude = alt_m_filt;
}

// ============================================================================
// Optical flow -> position integrate
// ============================================================================
static inline void updatePositionFromFlow(){
  int16_t dx, dy; uint8_t squal;
  if(!pmw_readMotion(dx,dy,squal)) return;
  if(squal < FLOW_SQUAL_MIN) return;

  float h_m = clampf(currentAltitude, 0.05f, 3.0f);

  float dX_body_m = (float)dx * (flowK * h_m);
  float dY_body_m = (float)dy * (flowK * h_m);

  dX_body_m = clampf(dX_body_m, -FLOW_MAX_STEP_M, FLOW_MAX_STEP_M);
  dY_body_m = clampf(dY_body_m, -FLOW_MAX_STEP_M, FLOW_MAX_STEP_M);

  float rad = currentYaw * DEG_TO_RAD;
  float c = cosf(rad), s = sinf(rad);

  float dXw = dX_body_m * c - dY_body_m * s;
  float dYw = dX_body_m * s + dY_body_m * c;

  currentPosX += dXw;
  currentPosY += dYw;
}

// ============================================================================
// Flow auto calibration (Serial: C / Dxx.x)
// ============================================================================
static inline void startFlowAutoCal(float dist_m=0.50f, float hoverAlt_m=0.80f, float pwr=35.0f){
  if(currentMode != MODE_READY && currentMode != MODE_HOVERING) return;

  flowCal_dist_m = dist_m;
  flowCal_hoverAlt_m = hoverAlt_m;
  flowCal_pwr = pwr;

  flowCal_sum_dx = 0;
  flowCal_samples = 0;
  flowCal_height_acc = 0.0f;
  flowCal_height_n = 0;
  flowCal_suggestK = 0.0f;
  flowCal_reported = false;

  flowCal = FC_TAKE_HOVER;
  Serial.println("FLOW CAL: START (send Dxx.x to refine with measured cm)");
}

static inline void flowCalTick(){
  if(flowCal == FC_IDLE || flowCal == FC_DONE || flowCal == FC_ABORT) return;
  if(currentMode == MODE_EMERGENCY){ flowCal = FC_ABORT; Serial.println("FLOW CAL: ABORT (EMERGENCY)"); return; }

  switch(flowCal){
    case FC_TAKE_HOVER: {
      if(currentMode == MODE_READY) currentMode = MODE_TAKEOFF;
      targetAltitude = flowCal_hoverAlt_m;

      if(currentMode == MODE_TAKEOFF){
        if(fabsf(currentAltitude - targetAltitude) < 0.08f){
          currentMode = MODE_HOVERING;
          targetPosX = currentPosX;
          targetPosY = currentPosY;
          targetYaw  = currentYaw;
        }
      }

      if(currentMode == MODE_HOVERING && fabsf(currentAltitude - targetAltitude) < 0.08f){
        flowCal_t0 = millis();
        flowCal = FC_FORWARD;
        Serial.println("FLOW CAL: FORWARD");
      }
    } break;

    case FC_FORWARD: {
      float step_m = (moveSpeedSteps[speedLevel] * (flowCal_pwr/100.0f)) * LOOP_DT;
      if(step_m < 0.002f) step_m = 0.002f;
      targetPosX += step_m;

      if(fabsf(currentPosX - targetPosX) > flowCal_dist_m){
        flowCal_t0 = millis();
        flowCal = FC_PAUSE1;
      }
    } break;

    case FC_PAUSE1: {
      if(millis() - flowCal_t0 > 500){
        flowCal_t0 = millis();
        flowCal = FC_BACK;
      }
    } break;

    case FC_BACK: {
      float step_m = (moveSpeedSteps[speedLevel] * (flowCal_pwr/100.0f)) * LOOP_DT;
      if(step_m < 0.002f) step_m = 0.002f;
      targetPosX -= step_m;

      if(fabsf(currentPosX - targetPosX) < 0.10f || (millis() - flowCal_t0) > 6000){
        flowCal_t0 = millis();
        flowCal = FC_PAUSE2;
      }
    } break;

    case FC_PAUSE2: {
      if(millis() - flowCal_t0 > 500){
        if(flowCal_samples < 50 || flowCal_height_n < 50){
          flowCal = FC_ABORT;
          Serial.println("FLOW CAL: ABORT (not enough samples)");
          break;
        }
        float avgH = flowCal_height_acc / (float)flowCal_height_n;
        float counts = (float)abs(flowCal_sum_dx);
        if(avgH < 0.10f || counts < 5.0f){
          flowCal = FC_ABORT;
          Serial.println("FLOW CAL: ABORT (bad data)");
          break;
        }

        flowCal_suggestK = flowCal_dist_m / (avgH * counts);
        flowK = flowCal_suggestK;
        prefs.putFloat("flowK", flowK);

        flowCal = FC_DONE;
        Serial.println("FLOW CAL: DONE");
      }
    } break;

    default: break;
  }

  if(flowCal == FC_DONE && !flowCal_reported){
    flowCal_reported = true;
    float avgH = (flowCal_height_n ? flowCal_height_acc/(float)flowCal_height_n : 0.0f);
    Serial.printf("FLOW CAL RESULT: avgH=%.2fm dxCounts=%ld flowK=%.6f (saved)\n",
                  avgH, (long)flowCal_sum_dx, flowK);
    Serial.println("If measured actual distance, send: D60.0  (cm)");
  }
}

// ============================================================================
// Serial commands (테스트/캘리브레이션/호버학습)
// ============================================================================
static inline void serialCommands(){
  if(!Serial.available()) return;
  String s = Serial.readStringUntil('\n');
  s.trim();
  if(s.length()==0) return;

  if(s == "C"){ startFlowAutoCal(0.50f, 0.80f, 35.0f); return; }
  if(s == "Y0"){ yawReset(); Serial.println("Yaw reset."); return; }

  if(s == "T"){ // takeoff (hover learn)
    if(currentMode == MODE_READY) {
      hover_startLearn();
      Serial.println("Takeoff: hover learn started.");
    }
    return;
  }
  if(s == "L"){
    if(currentMode != MODE_READY) currentMode = MODE_LANDING;
    Serial.println("Landing.");
    return;
  }
  if(s == "K"){
    currentMode = MODE_EMERGENCY;
    motorsOff();
    Serial.println("KILL MOTORS!");
    return;
  }

  if(s.startsWith("D")){
    float actual_cm = s.substring(1).toFloat();
    if(actual_cm > 5.0f && actual_cm < 300.0f){
      float avgH = (flowCal_height_n ? flowCal_height_acc/(float)flowCal_height_n : currentAltitude);
      float counts = (float)abs(flowCal_sum_dx);
      if(avgH > 0.10f && counts > 5.0f){
        float actual_m = actual_cm * 0.01f;
        flowK = actual_m / (avgH * counts);
        prefs.putFloat("flowK", flowK);
        Serial.printf("FLOW CAL REFINE: actual=%.1fcm => flowK=%.6f (saved)\n", actual_cm, flowK);
      }
    }
    return;
  }
}

// ============================================================================
// POST + Calibration
// ============================================================================
static inline bool postSensors(){
  ok_imu  = imu_init_auto();
  ok_baro = spl_init();
  ok_tof  = tof_init();
  ok_flow = pmw_init();

  ledSet(ok_imu, ok_baro, ok_tof, ok_flow);

  // 필수: Baro + ToF + Flow (IMU는 실패해도 비행은 가능하게 설계했지만 권장)
  flightLock = !(ok_baro && ok_tof && ok_flow);

  if(flightLock){
    Serial.printf("POST FAIL -> FLIGHT LOCK (IMU=%d BARO=%d TOF=%d FLOW=%d)\n",
                  ok_imu, ok_baro, ok_tof, ok_flow);
    ledFailPattern();
    return false;
  }
  Serial.printf("POST OK (IMU=%d BARO=%d TOF=%d FLOW=%d)\n",
                ok_imu, ok_baro, ok_tof, ok_flow);
  return true;
}

static inline bool calibrateSensors(){
  // Baro baseline
  float sumP=0; int got=0;
  for(int i=0;i<200;i++){
    float p;
    if(spl_readPressurePa(p)){ sumP += p; got++; }
    delay(10);
  }
  if(got < 120) return false;
  basePressurePa = sumP / got;

  // reset filters
  altInit=false;
  baroInit=false;
  tofFiltInit=false;

  // IMU gyro bias (optional)
  if(ok_imu){
    if(!imu_calibrate_gyroZ()){
      ok_imu = false;
    }
  }
  yawReset();

  calibrated = true;
  return true;
}

// ============================================================================
// Public APIs
// ============================================================================
static inline void calibrate(){
  if(currentMode == MODE_READY){
    Serial.println("AF: calibrate (ground)");
    if(!calibrateSensors()){
      Serial.println("AF: calibrate FAIL -> lock");
      flightLock = true;
      ledFailPattern();
    } else {
      Serial.println("AF: calibrate OK");
    }
  }
}

static inline void autoTakeoff(){
  if(flightLock){
    Serial.println("AF: FLIGHT LOCK - takeoff blocked");
    currentMode = MODE_READY;
    motorsOff();
    return;
  }
  if(currentMode == MODE_READY){
    hover_startLearn(); // ✅ A 방식 시작
  }
}

static inline void autoLanding(){
  if(currentMode != MODE_READY){
    currentMode = MODE_LANDING;
  }
}

static inline void emergencyStop(){
  currentMode = MODE_EMERGENCY;
  motorsOff();
}

// ============================================================================
// updateSystem / updateFlight
// ============================================================================
static inline void updateSystem(){
  binding_update();
  if (!binding_isBound()) {
    // 아직 바인딩 안 됐으면 조종 수신/비행 금지
    currentMode = MODE_READY;
    motorsOff();
    return;
  }
  updateRadio();
  serialCommands();  

  if(ok_imu) imu_updateYaw();
  binding_update(); 
  else currentYaw = 0.0f;

  updateAltitudeFusion();
  updatePositionFromFlow();
  flowCalTick();

  // ✅ Hover 상태머신 tick (A 방식)
  hover_update();

// ============================================================
  // [NEW] 조종기 스틱 입력 처리 (Manual Control Logic)
  // ============================================================
  if (currentMode == MODE_HOVERING && !failsafe) {
    // 1. 데드존 설정 (중앙 127 기준 ±10 정도는 무시)
    int rawRoll = receiverData.roll;
    int rawPitch = receiverData.pitch;
    int rawThr = receiverData.throttle;
    int rawYaw = receiverData.yaw;

    float vX_cmd = 0.0f; // 좌우 이동 속도 명령
    float vY_cmd = 0.0f; // 전후 이동 속도 명령

    // Roll (좌우)
    if (abs(rawRoll - 127) > 10) {
      // 입력값(-127~127)을 정규화(-1.0~1.0) 후 현재 속도 모드(moveSpeedSteps) 곱하기
      float input = (float)(rawRoll - 127) / 127.0f;
      vX_cmd = input * moveSpeedSteps[speedLevel]; 
    }

    // Pitch (전후)
    if (abs(rawPitch - 127) > 10) {
      float input = (float)(rawPitch - 127) / 127.0f;
      vY_cmd = input * moveSpeedSteps[speedLevel];
    }

    if (vX_cmd != 0.0f || vY_cmd != 0.0f) {
    float rad = currentYaw * DEG_TO_RAD;
    float c = cosf(rad);
    float s = sinf(rad);

    float dX_world = (vY_cmd * c - vX_cmd * s) * LOOP_DT;
    float dY_world = (vY_cmd * s + vX_cmd * c) * LOOP_DT;

    const float MAX_TARGET_STEP = 0.08f * LOOP_DT; // 목표 이동 제한
    dX_world = clampf(dX_world, -MAX_TARGET_STEP, MAX_TARGET_STEP);
    dY_world = clampf(dY_world, -MAX_TARGET_STEP, MAX_TARGET_STEP);

    targetPosX += dX_world;
    targetPosY += dY_world;
   }

    // Yaw (회전)
    if (abs(rawYaw - 127) > 10) {
      float input = (float)(rawYaw - 127) / 127.0f;
      // 회전 속도 적용 (deg/sec -> loop dt 고려)
      targetYaw += input * yawSpeedSteps[speedLevel] * LOOP_DT;
    }

    // Throttle (고도 미세 조정 - Optional)
    // 호버링 중 스로틀을 위/아래로 밀면 고도 목표를 변경
    if (abs(rawThr - 127) > 20) {
      float input = (float)(rawThr - 127) / 127.0f;
      targetAltitude += input * climbSpeedSteps[speedLevel] * LOOP_DT;
      // 고도 안전 제한 (0.1m ~ 2.5m)
      if (targetAltitude < 0.1f) targetAltitude = 0.1f;
      if (targetAltitude > 2.5f) targetAltitude = 2.5f;
    }

    // 2. 좌표계 변환 (드론의 Head 방향 기준으로 이동하도록)
    // 드론이 회전해 있어도 "앞으로 밀면" 드론 기준 앞쪽으로 가야 함
    if (vX_cmd != 0.0f || vY_cmd != 0.0f) {
      float rad = currentYaw * DEG_TO_RAD;
      float c = cosf(rad);
      float s = sinf(rad);

      // Body Frame 속도를 World Frame 이동량으로 변환
      // X_world = X_body * cos - Y_body * sin
      // Y_world = X_body * sin + Y_body * cos
      // (주의: 위 수식은 좌표계 정의에 따라 부호가 다를 수 있음. 
      //  일반적으로 Roll=X, Pitch=Y 일 때 아래와 같음)
      
      // Pitch(Y_cmd)가 전진, Roll(X_cmd)가 우측 이동이라 가정
      float dX_world = (vY_cmd * c - vX_cmd * s) * LOOP_DT; 
      float dY_world = (vY_cmd * s + vX_cmd * c) * LOOP_DT;

      targetPosX += dX_world;
      targetPosY += dY_world;
    }
  }
  // ============================================================


  // LED update
  ledSet(ok_imu, ok_baro, ok_tof, ok_flow);
}

static inline void updateFlight(){
  if(currentMode == MODE_READY || currentMode == MODE_EMERGENCY){
    motorsOff();
    return;
  }

  // TAKEOFF -> HOVERING은 hover header가 안정되면 currentMode=HOVERING으로 바꿈
  // LANDING
  if(currentMode == MODE_LANDING){
    targetAltitude -= LAND_DESCEND_MPS * LOOP_DT;
    targetAltitude = clampf(targetAltitude, 0.0f, 3.0f);
    if(currentAltitude < READY_ALT_M){
      currentMode = MODE_READY;
      motorsOff();
      return;
    }
  }

  // Position P
  float ex = (targetPosX - currentPosX);
  float ey = (targetPosY - currentPosY);
  float r_cmd = ex * POS_KP;
  float p_cmd = ey * POS_KP;

  // Yaw P
  float eyaw = (targetYaw - currentYaw);
  while(eyaw > 180.0f) eyaw -= 360.0f;
  while(eyaw < -180.0f) eyaw += 360.0f;
  float y_cmd = eyaw * YAW_KP;

  // Altitude PD
  float zErr = (targetAltitude - currentAltitude);
  float zVel = (alt_m_filt - alt_m_prev) / LOOP_DT;
  float zCmd = (zErr * ALT_KP) - (zVel * ALT_KD);

  // ✅ Hover 학습이 hoverThrottle을 자동으로 맞추도록 피드백
  hover_onZcmd(zCmd);

  int thr = hoverThrottle + (int)(zCmd * 100.0f);
  thr = constrain(thr, 0, 255);

  motorControl(thr, r_cmd, p_cmd, y_cmd);
}

// ============================================================================
// init
// ============================================================================
static inline void initAF1000X(){
  Serial.println("AF1000X: init");

  ledsInit();
  motorsInit();

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  Wire.setClock(400000);

  SPI.begin(PIN_SPI_SCK, PIN_SPI_MISO, PIN_SPI_MOSI);

  radioInit();

  prefs.begin("af1000x", false);
  flowK = prefs.getFloat("flowK", flowK);
  Serial.printf("flowK=%.6f (loaded)\n", flowK);

  // POST + calibration
  postSensors();
  if(!flightLock){
    if(!calibrateSensors()){
      flightLock = true;
      ledFailPattern();
    }
  }

  binding_begin();

  hover_begin(); // hoverPWM 로드(hoverThrottle에 적용)

  currentMode = MODE_READY;
  Serial.printf("AF1000X: READY (lock=%d)\n", (int)flightLock);
}

#endif // AF1000X_H
