#ifndef AF1000X_BINDING_H
#define AF1000X_BINDING_H

#include <Arduino.h>
#include <RF24.h>
#include <Preferences.h>
#include <math.h>

// Provided by AF1000X.h
extern RF24 radio;
extern Preferences prefs;

extern float currentRoll;
extern float currentPitch;

extern volatile FlightMode mode;
extern bool flightLock;
extern bool isBound;

extern void ledRed(bool on);
extern void ledGreen(bool on);
extern void ledBlue(bool on);

// Pairing constants
static const uint8_t AF_PAIR_ADDR[5] = {0xE8,0xE8,0xF0,0xF0,0xE1};
static const uint8_t AF_PAIR_CHANNEL = 76;
static const uint32_t AF_BIND_MAGIC  = 0xAF1000B1;
static const uint32_t AF_PAIR_WINDOW_MS = 5000;

static const char* AF_KEY_BIND_VALID = "bind_ok";
static const char* AF_KEY_BIND_INFO  = "bind_info";

struct BindReq {
  uint32_t magic;
  uint32_t tx_id;
  uint8_t  rf_addr[5];
  uint8_t  rf_channel;
  uint32_t token;
};

struct BindInfo {
  uint32_t tx_id;
  uint8_t  rf_addr[5];
  uint8_t  rf_channel;
  uint32_t token;
};

static bool     _af_pairingActive = false;
static uint32_t _af_bootMs = 0;
static BindInfo _af_bindInfo;

static inline bool _af_isInverted() {
  return (fabsf(currentRoll) > 150.0f) || (fabsf(currentPitch) > 150.0f);
}

static inline void _af_ledPairing() { ledBlue(true); ledGreen(false); ledRed(false); }
static inline void _af_ledBound()   { ledGreen(true); ledBlue(false); ledRed(false); }
static inline void _af_ledError()   { ledRed(true); ledGreen(false); ledBlue(false); }

static bool _af_loadBindInfo() {
  if (!prefs.getBool(AF_KEY_BIND_VALID, false)) return false;
  prefs.getBytes(AF_KEY_BIND_INFO, &_af_bindInfo, sizeof(_af_bindInfo));
  if (_af_bindInfo.rf_channel > 125) return false;
  return true;
}

static void _af_saveBindInfo(const BindReq& req) {
  _af_bindInfo.tx_id = req.tx_id;
  memcpy(_af_bindInfo.rf_addr, req.rf_addr, 5);
  _af_bindInfo.rf_channel = req.rf_channel;
  _af_bindInfo.token = req.token;

  prefs.putBytes(AF_KEY_BIND_INFO, &_af_bindInfo, sizeof(_af_bindInfo));
  prefs.putBool(AF_KEY_BIND_VALID, true);
}

static void _af_applyBoundRadio() {
  radio.stopListening();
  radio.setChannel(_af_bindInfo.rf_channel);
  radio.openReadingPipe(1, _af_bindInfo.rf_addr);
  radio.startListening();
  _af_ledBound();
}

static void _af_enterPairingMode() {
  _af_pairingActive = true;
  radio.stopListening();
  radio.setChannel(AF_PAIR_CHANNEL);
  radio.openReadingPipe(1, AF_PAIR_ADDR);
  radio.startListening();
  _af_ledPairing();
}

static inline void binding_begin() {
  _af_bootMs = millis();
  _af_pairingActive = false;

  if (_af_loadBindInfo()) {
    _af_applyBoundRadio();
    isBound = true;
    flightLock = false;
  } else {
    isBound = false;
    flightLock = true;
    _af_ledError();
  }
}

static inline void binding_update() {
  // If already bound and not pairing, nothing to do
  if (!_af_pairingActive && isBound) return;

  // Enter pairing only within first 5s and inverted
  if (!_af_pairingActive) {
    if (millis() - _af_bootMs < AF_PAIR_WINDOW_MS && _af_isInverted()) {
      _af_enterPairingMode();
    }
    return;
  }

  // Pairing RX
  if (radio.available()) {
    BindReq req;
    radio.read(&req, sizeof(req));
    if (req.magic != AF_BIND_MAGIC) return;
    if (req.rf_channel > 125) return;

    _af_saveBindInfo(req);
    _af_pairingActive = false;
    isBound = true;
    flightLock = false;
    _af_applyBoundRadio();
    mode = MODE_READY;
  }
}

#endif // AF1000X_BINDING_H
